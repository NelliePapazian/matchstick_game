﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragAndDrop : MonoBehaviour {

    public enum matchstickType { normal, withPoint };


    public Transform correctPlace;
    bool moving;
    bool locked;
    float startPosX;
    float startPosY;
    private Vector3 startPos;
    public matchstickType type = matchstickType.normal;


    void Start()
    {
        startPos = transform.localPosition;
    }

    void Update()
    {
        if (moving && !locked)
        {
            Vector3 mousePos;
            mousePos = Input.mousePosition;
            mousePos = Camera.main.ScreenToWorldPoint(mousePos);
            gameObject.transform.localPosition = new Vector3(mousePos.x - startPosX, mousePos.y - startPosY, gameObject.transform.localPosition.z);
        }
    }

    void OnMouseDown()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Vector3 mousePos;
            mousePos = Input.mousePosition;
            mousePos = Camera.main.ScreenToWorldPoint(mousePos);

            startPosX = mousePos.x - transform.localPosition.x;
            startPosY = mousePos.y - transform.localPosition.y;
            moving = true;

        }
    }

    void OnMouseUp()
    {
        moving = false;
        if(type == matchstickType.withPoint)
        {
            if (Mathf.Abs(transform.position.x - correctPlace.localPosition.x) <= 2.5f && Mathf.Abs(transform.position.y - correctPlace.localPosition.y) <= 2.5f)
            {
                if (!locked)
                {
                    GameManager.index++;
                    Debug.Log(GameManager.index);
                }
                transform.position = new Vector3(correctPlace.position.x, correctPlace.position.y, correctPlace.position.z);
                locked = true;

            }
            else
            {
                transform.localPosition = new Vector3(startPos.x, startPos.y, startPos.z);
            }
        }
        else
        {
            transform.localPosition = new Vector3(startPos.x, startPos.y, startPos.z);
        }

    }
}
