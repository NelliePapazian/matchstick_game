﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Removing : MonoBehaviour {

    public enum matchstickType { normal, removeable };

    Animation anim;
    public matchstickType type = matchstickType.normal;

    void Start () {
        anim = gameObject.GetComponent<Animation>();
    }

    void OnMouseDown()
    {
        if(type == matchstickType.normal)
        {
            anim.Play("wrongMatchstick");
        }
        else
        {
            GameManager.index++;
            Destroy(gameObject);
        }
    }

}
