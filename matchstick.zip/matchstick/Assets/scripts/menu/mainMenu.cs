﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class mainMenu : MonoBehaviour {

    public sceneFader fader;
    public string LevelToLoad;
 
	public void play()
    {
        GameManager.index = 0;
        fader.FadeTo(LevelToLoad);
    }

    public void quit()
    {
        Application.Quit();
    }

}
