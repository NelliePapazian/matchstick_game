﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class NextLevelMenu : MonoBehaviour {

    int MaxBuildIndex = 6;
    public sceneFader fader;
    public string levelToFade;
    public Text stateText;

    void Start()
    {
        stateText.enabled = false;
    }

	public void NextLevel()
    {
        if (SceneManager.GetActiveScene().buildIndex == MaxBuildIndex)
        {
            stateText.enabled = true;
            stateText.text = "All Levels Cleared";
        }
        else
        {
            fader.FadeTo(levelToFade);
           
        }

    }
    public void Menu()
    {
        fader.FadeTo("Menu");
    }
}
