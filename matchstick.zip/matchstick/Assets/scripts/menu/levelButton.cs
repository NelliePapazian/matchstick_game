﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class levelButton : MonoBehaviour {

    public sceneFader fader;
    public string LevelName;

	public void LoadLevel()
    {
        fader.FadeTo(LevelName);
    }
}
